package com.example.apkguard;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class MainActivity extends AppCompatActivity {

    TextView resultText;
    TextView blockedText;

    Button allowButton;
    Button blockButton;
    Button complaintButton;

    Uri apkUri;

    String SUPABASE_URL =
            "https://npfvvegmxgkkhyxkephc.supabase.co/rest/v1/threat_reports";

    String SUPABASE_KEY =
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5wZnZ2ZWdteGdra2h5eGtlcGhjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzczODQzNzQsImV4cCI6MjA5Mjk2MDM3NH0.S4wKfp_5b_KJKyt4_yobbPZY6VVdyoaIHmGJXQs2FgU";

    String lastAppName = "";
    int lastRiskScore = 0;
    String lastRiskLevel = "";
    String lastHash = "";
    String lastPermissions = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultText = findViewById(R.id.resultText);
        blockedText = findViewById(R.id.blockedText);

        allowButton = findViewById(R.id.allowButton);
        blockButton = findViewById(R.id.blockButton);
        complaintButton = findViewById(R.id.complaintButton);

        Intent intent = getIntent();
        apkUri = intent.getData();

        if (apkUri != null) {

            resultText.setText("Scanning APK...\n");

            File apkFile = copyUriToFile(apkUri);

            if (apkFile != null) {

                String apkHash =
                        generateAPKHash(apkFile);

                checkBlacklist(apkHash);

                PackageManager pm =
                        getPackageManager();

                PackageInfo packageInfo =
                        pm.getPackageArchiveInfo(
                                apkFile.getAbsolutePath(),
                                PackageManager.GET_PERMISSIONS
                        );

                if (packageInfo != null) {

                    String appName =
                            packageInfo.packageName;

                    String permissions = "";

                    boolean camera = false;
                    boolean microphone = false;
                    boolean sms = false;
                    boolean contacts = false;
                    boolean internet = false;

                    if (packageInfo.requestedPermissions != null) {

                        for (String perm :
                                packageInfo.requestedPermissions) {

                            permissions +=
                                    getPermissionExplanation(perm)
                                            + "\n";

                            if (perm.contains("CAMERA"))
                                camera = true;

                            if (perm.contains("RECORD_AUDIO"))
                                microphone = true;

                            if (perm.contains("SMS"))
                                sms = true;

                            if (perm.contains("READ_CONTACTS"))
                                contacts = true;

                            if (perm.contains("INTERNET"))
                                internet = true;

                        }

                    }

                    int riskScore = 0;

                    if (camera && microphone)
                        riskScore += 40;

                    if (sms)
                        riskScore += 40;

                    if (contacts)
                        riskScore += 20;

                    if (camera && internet)
                        riskScore += 30;

                    String riskLevel;

                    if (riskScore <= 40)
                        riskLevel = "SUSPICIOUS";
                    else
                        riskLevel = "DANGEROUS";

                    lastAppName = appName;
                    lastRiskScore = riskScore;
                    lastRiskLevel = riskLevel;
                    lastHash = apkHash;
                    lastPermissions = permissions;

                    resultText.setText(

                            "APK Guard Scanner\n\n"
                                    + "App Name:\n"
                                    + appName
                                    + "\n\nRisk Score:\n"
                                    + riskScore
                                    + "\nRisk Level:\n"
                                    + riskLevel
                                    + "\n\nPermissions:\n"
                                    + permissions
                    );

                }

            }

        }

        complaintButton.setOnClickListener(v -> {

            if (lastRiskScore > 40) {

                sendToSupabase(
                        lastAppName,
                        lastRiskScore,
                        lastRiskLevel,
                        lastHash,
                        lastPermissions
                );

                if (lastRiskScore > 100) {

                    autoBlacklist(lastHash);

                    autoBlockAfterDelay();

                }

            }

        });

    }

    // BLOCK AFTER 10 SEC

    private void autoBlockAfterDelay() {

        new Handler().postDelayed(() -> {

            allowButton.setVisibility(Button.GONE);
            complaintButton.setVisibility(Button.GONE); // ✅ FIX
            blockedText.setVisibility(TextView.VISIBLE);

        }, 10000);

    }

    // CHECK BLACKLIST

    private void checkBlacklist(String apkHash) {

        new Thread(() -> {

            try {

                OkHttpClient client =
                        new OkHttpClient();

                String url =
                        "https://npfvvegmxgkkhyxkephc.supabase.co/rest/v1/apk_blacklist?apk_hash=eq."
                                + apkHash;

                Request request =
                        new Request.Builder()
                                .url(url)
                                .addHeader("apikey", SUPABASE_KEY)
                                .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                                .get()
                                .build();

                okhttp3.Response response =
                        client.newCall(request).execute();

                String responseBody =
                        response.body().string();

                if (!responseBody.equals("[]")) {

                    runOnUiThread(() -> {

                        allowButton.setVisibility(Button.GONE);
                        complaintButton.setVisibility(Button.GONE); // ✅ FIX
                        blockedText.setVisibility(TextView.VISIBLE);

                        resultText.setText(
                                "🚫 BLACKLISTED APK DETECTED\n\n"
                                        + "This APK is already blocked.\n"
                                        + "Installation is not allowed."
                        );

                    });

                }

            }

            catch (Exception e) {

                e.printStackTrace();

            }

        }).start();

    }

    // SEND TO SUPABASE

    private void sendToSupabase(
            String appName,
            int riskScore,
            String riskLevel,
            String apkHash,
            String permissions) {

        new Thread(() -> {

            try {

                OkHttpClient client =
                        new OkHttpClient();

                String cleanPermissions =
                        permissions.replace("\n", ", ");

                String json =
                        "[{" +
                                "\"app_name\":\"" + appName + "\"," +
                                "\"risk_score\":" + riskScore + "," +
                                "\"risk_level\":\"" + riskLevel + "\"," +
                                "\"apk_hash\":\"" + apkHash + "\"," +
                                "\"permissions\":\"" + cleanPermissions + "\"" +
                                "}]";

                RequestBody body =
                        RequestBody.create(
                                json,
                                MediaType.parse("application/json"));

                Request request =
                        new Request.Builder()
                                .url(SUPABASE_URL)
                                .addHeader("apikey", SUPABASE_KEY)
                                .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                                .addHeader("Content-Type", "application/json")
                                .addHeader("Prefer", "return=representation")
                                .post(body)
                                .build();

                okhttp3.Response response =
                        client.newCall(request).execute();

                int code = response.code();

                runOnUiThread(() -> {

                    Toast.makeText(
                            MainActivity.this,
                            "Complaint Raised Successfully\nSupabase Code: " + code,
                            Toast.LENGTH_LONG
                    ).show();

                });

            }

            catch (Exception e) {

                e.printStackTrace();

            }

        }).start();

    }

    // AUTO BLACKLIST

    private void autoBlacklist(String apkHash) {

        new Thread(() -> {

            try {

                OkHttpClient client =
                        new OkHttpClient();

                String json =
                        "[{" +
                                "\"apk_hash\":\"" + apkHash + "\"," +
                                "\"app_name\":\"" + lastAppName + "\"," +
                                "\"risk_level\":\"" + lastRiskLevel + "\"," +
                                "\"blocked_by\":\"APK Guard System\"" +
                                "}]";

                RequestBody body =
                        RequestBody.create(
                                json,
                                MediaType.parse("application/json")
                        );

                Request request =
                        new Request.Builder()

                                .url("https://npfvvegmxgkkhyxkephc.supabase.co/rest/v1/apk_blacklist")

                                .addHeader("apikey", SUPABASE_KEY)

                                .addHeader(
                                        "Authorization",
                                        "Bearer " + SUPABASE_KEY)

                                .addHeader(
                                        "Content-Type",
                                        "application/json")

                                .addHeader(
                                        "Prefer",
                                        "return=representation")

                                .post(body)

                                .build();

                client.newCall(request).execute();

            }

            catch (Exception e) {

                e.printStackTrace();

            }

        }).start();

    }

    // HASH

    private String generateAPKHash(File file) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            FileInputStream fis =
                    new FileInputStream(file);

            byte[] byteArray =
                    new byte[1024];

            int bytesCount;

            while ((bytesCount =
                    fis.read(byteArray)) != -1) {

                digest.update(byteArray, 0, bytesCount);

            }

            fis.close();

            byte[] bytes = digest.digest();

            StringBuilder hexString =
                    new StringBuilder();

            for (byte b : bytes) {

                String hex =
                        Integer.toHexString(0xff & b);

                if (hex.length() == 1)
                    hexString.append('0');

                hexString.append(hex);

            }

            return hexString.toString();

        }

        catch (Exception e) {

            return "HASH_ERROR";

        }

    }

    // COPY FILE

    private File copyUriToFile(Uri uri) {

        try {

            File file =
                    new File(getCacheDir(),
                            "temp_apk.apk");

            InputStream inputStream =
                    getContentResolver()
                            .openInputStream(uri);

            FileOutputStream outputStream =
                    new FileOutputStream(file);

            byte[] buffer =
                    new byte[1024];

            int length;

            while ((length =
                    inputStream.read(buffer)) > 0) {

                outputStream.write(buffer, 0, length);

            }

            outputStream.close();
            inputStream.close();

            return file;

        }

        catch (Exception e) {

            return null;

        }

    }

    // PERMISSION NAMES

    private String getPermissionExplanation(String permission) {

        if (permission.contains("CAMERA"))
            return "📷 Camera Access";

        if (permission.contains("RECORD_AUDIO"))
            return "🎤 Microphone Access";

        if (permission.contains("SMS"))
            return "📩 SMS Access";

        if (permission.contains("READ_CONTACTS"))
            return "👥 Contacts Access";

        if (permission.contains("INTERNET"))
            return "🌐 Internet Access";

        return permission;

    }

}