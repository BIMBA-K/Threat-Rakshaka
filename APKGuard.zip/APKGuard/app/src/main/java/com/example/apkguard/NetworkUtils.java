package com.example.apkguard;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class NetworkUtils {

    public static void sendData(
            String apkName,
            String risk,
            String permissions
    ) {

        new Thread(() -> {

            try {

                URL url =
                        new URL(
                                "http://192.168.1.100:5000/report"
                        );

                HttpURLConnection conn =
                        (HttpURLConnection)
                                url.openConnection();

                conn.setRequestMethod("POST");

                conn.setDoOutput(true);

                conn.setRequestProperty(
                        "Content-Type",
                        "application/json"
                );

                String json =
                        "{"
                                + "\"apk_name\":\""
                                + apkName
                                + "\","

                                + "\"risk\":\""
                                + risk
                                + "\","

                                + "\"permissions\":\""
                                + permissions
                                + "\""
                                + "}";

                OutputStream os =
                        conn.getOutputStream();

                os.write(json.getBytes());

                os.flush();

                os.close();

                conn.getResponseCode();

            }

            catch (Exception e) {

                e.printStackTrace();

            }

        }).start();

    }

}